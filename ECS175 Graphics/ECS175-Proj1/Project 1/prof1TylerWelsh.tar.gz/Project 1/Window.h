#pragma once

#ifndef WINDOW_H
#define WINDOW_H
//Window stats
//Defaults to 800x600

extern int WIDTH;
extern int HEIGHT;
extern int MID_X;
extern int MID_Y;

#endif
