To create the tables and populate with regular data:
python2 createTables.py

To create the tables and populate with subset data:
python2 createSubsetTables.py

To run all queries for problem 3 (which are reported in 165HW4_Tyler_Brian
python2 queries.py