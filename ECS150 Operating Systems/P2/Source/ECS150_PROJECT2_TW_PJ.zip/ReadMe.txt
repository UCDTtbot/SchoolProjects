ECS150 Project 2:
Tyler Welsh
Patrick Johnston

Works 98% sort of...
If testing preempt, hangs.
Mutex prints out of order.